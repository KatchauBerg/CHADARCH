# 🚀 INSTALAÇÃO E SETUP - 5 Minutos

## 📥 1. Instalar Obsidian

### Linux
```bash
sudo snap install obsidian --classic
```

### Windows
https://obsidian.md/download

### macOS
```bash
brew install --cask obsidian
```

---

## 📂 2. Abrir o Vault

1. **Extrair ZIP**
   ```bash
   unzip obsidian-vault-completo.zip
   ```

2. **Abrir Obsidian**
   - Clique em "Open folder as vault"
   - Selecione pasta `obsidian-vault-completo`
   - Aguarde indexação (alguns segundos)

---

## 🔌 3. Instalar Plugins (ESSENCIAL!)

**Settings → Community Plugins:**

1. Click **"Turn off Restricted Mode"**

2. Click **"Browse"** e instalar:
   - ✅ **Dataview** (essencial para Dashboard!)
   - ✅ **Kanban** (essencial para Board!)
   - ✅ **Calendar** (recomendado)
   - ⚪ Excalidraw (opcional - diagramas)

3. **Enable** cada plugin após instalar!

**Verificar:**
- Dataview enabled? Settings → Community Plugins → Dataview → ✅
- Kanban enabled? Settings → Community Plugins → Kanban → ✅

---

## ✅ 4. Verificar Funcionamento

### Teste 1: Dashboard
1. Abra `🎯 Dashboard/Dashboard-Principal.md`
2. Deve ver queries do Dataview
3. Se vazio, Dataview não está instalado!

### Teste 2: Kanban
1. Abra `📋 Kanban/Board-Geral.md`
2. Clique no ícone Kanban (topo direito)
3. Deve ver colunas com cards

---

## 🎯 5. Começar a Usar!

**Agora:**
1. Leia `README.md` (5 min)
2. Ou vá direto: `📅 Rotina-Diaria/Dia-001.md`
3. **FAÇA!**

---

## 🐛 Troubleshooting

### Dataview vazio no Dashboard?
→ Settings → Community Plugins → Dataview → Enable

### Kanban não aparece?
→ Abra arquivo .md → Clique ícone Kanban no canto

### Daily notes não criam automático?
→ Settings → Daily notes → Enable
→ Template: `Templates/Template-Daily-Note.md`

---

## 💡 Próximos Passos

- [ ] Setup completo
- [ ] Plugins instalados
- [ ] Dashboard funciona
- [ ] Li o README
- [ ] Abri Dia-001
- [ ] **COMECEI!** 🚀

---

**Tudo pronto? Bora estudar!**

*[[README|← Voltar ao README]]*
