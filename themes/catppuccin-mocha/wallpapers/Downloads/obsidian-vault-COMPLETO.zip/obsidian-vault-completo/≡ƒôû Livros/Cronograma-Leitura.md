# 📖 Cronograma de Leitura Diário

## Mês 1 (Dias 1-30): Programming from the Ground Up

| Dia | Páginas | Tópico |
|-----|---------|--------|
| 1 | 15-35 | Intro + Conceitos |
| 3 | 36-55 | Primeiro Programa |
| 5 | 56-75 | Funções Básicas |
| 7 | 76-95 | Funções Avançadas |
| 9 | 96-115 | Arquivos |
| 11 | 116-140 | Registros |
| 13 | 141-165 | Estruturas |
| 15 | 166-190 | Tipos de Dados |
| 17 | 191-215 | Shared Libraries |
| 19 | 216-240 | Counting |
| 21 | 241-265 | High-Level |
| 23 | 266-280 | Otimização |

**Meta:** 10 páginas/dia nos dias ímpares

---

## Mês 2-3: Computer Organization & Design

**Caps importantes:** 1, 2, 4, 5

---

## Como Usar

Os arquivos `Dia-XXX.md` JÁ dizem o que ler!

Você só precisa seguir.

**Tags:** #livros #cronograma
