# 📅 Índice - Primeiros 90 Dias

> **Roadmap completo dos primeiros 3 meses**

---

## 🎯 Visão Geral

**Sistema de Dias:**
- **Ímpares (1, 3, 5, 7...):** Leitura + Teoria
- **Pares (2, 4, 6, 8...):** Prática + Labs

**Temas rotativos:**
- 🔧 Assembly
- 🔍 Pentesting
- 💻 Arquitetura
- 💥 Exploits (depois)

---

## 📆 Mês 1 (Dias 1-30): Fundamentos

### Semana 1 (Dias 1-7)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 001 | Assembly | Registradores | - |
| 002 | Pentesting | SQL Injection | ✅ TryHackMe |
| 003 | Assembly | Stack e Funções | - |
| 004 | Pentesting | Nmap Scanning | ✅ TryHackMe |
| 005 | Arquitetura | CPU Pipeline | - |
| 006 | Pentesting | Burp Suite | ✅ TryHackMe |
| 007 | Assembly | x64 Basics | - |

**Meta da semana:**
- [ ] 7 dias completados
- [ ] 3 labs TryHackMe
- [ ] PGTU: 70 páginas
- [ ] 5+ programas Assembly

---

### Semana 2 (Dias 8-14)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 008 | Pentesting | XSS | ✅ TryHackMe |
| 009 | Assembly | Syscalls | - |
| 010 | Pentesting | Linux Enum | ✅ TryHackMe |
| 011 | Arquitetura | Cache Memory | - |
| 012 | Pentesting | Metasploit | ✅ TryHackMe |
| 013 | Assembly | String Operations | - |
| 014 | Projeto | Mini Projeto Assembly | - |

**Meta da semana:**
- [ ] 14 dias total
- [ ] 6 labs TryHackMe
- [ ] PGTU: 140 páginas
- [ ] Primeiro mini-projeto

---

### Semana 3 (Dias 15-21)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 015 | Assembly | SIMD (SSE) Intro | - |
| 016 | Pentesting | Web Fuzzing | ✅ TryHackMe |
| 017 | Arquitetura | Virtual Memory | - |
| 018 | Pentesting | File Upload Vuln | ✅ TryHackMe |
| 019 | Assembly | Inline Assembly (C) | - |
| 020 | Pentesting | Command Injection | ✅ TryHackMe |
| 021 | Arquitetura | Paginação | - |

**Meta da semana:**
- [ ] 21 dias total
- [ ] 9 labs TryHackMe
- [ ] PGTU: 210 páginas
- [ ] Entender SIMD basics

---

### Semana 4 (Dias 22-30)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 022 | Pentesting | IDOR | ✅ TryHackMe |
| 023 | Assembly | Debugging Avançado | - |
| 024 | Pentesting | SSRF | ✅ TryHackMe |
| 025 | Arquitetura | TLB | - |
| 026 | Pentesting | XXE | ✅ TryHackMe |
| 027 | Assembly | ELF Format | - |
| 028 | Pentesting | Privilege Escalation | ✅ TryHackMe |
| 029 | Projeto | Keylogger Início | - |
| 030 | Projeto | Keylogger Continuação | - |

**Meta da semana:**
- [ ] 30 dias completados! 🎉
- [ ] 13 labs TryHackMe
- [ ] PGTU: Completo (280 pág)
- [ ] Projeto Keylogger 50%

---

## 📆 Mês 2 (Dias 31-60): Aprofundamento

### Semana 5 (Dias 31-37)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 031 | Exploits | Buffer Overflow Intro | - |
| 032 | Pentesting | Active Directory Basics | ✅ TryHackMe |
| 033 | Exploits | Stack Smashing | - |
| 034 | Pentesting | Kerberos | ✅ TryHackMe |
| 035 | Arquitetura | COD Cap 2 Início | - |
| 036 | Pentesting | BloodHound | ✅ TryHackMe |
| 037 | Exploits | Shellcode Writing | - |

**Foco:** Exploits começam!

---

### Semana 6 (Dias 38-44)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 038 | Pentesting | AS-REP Roasting | ✅ TryHackMe |
| 039 | Exploits | ASLR Bypass | - |
| 040 | Pentesting | Kerberoasting | ✅ TryHackMe |
| 041 | Reversing | IDA Pro Basics | - |
| 042 | Pentesting | DCSync | ✅ TryHackMe |
| 043 | Reversing | Static Analysis | - |
| 044 | Pentesting | Golden Ticket | ✅ TryHackMe |

**Foco:** AD attacks + Reversing

---

### Semana 7 (Dias 45-51)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 045 | Exploits | ROP Chains Intro | - |
| 046 | Pentesting | Lateral Movement | ✅ TryHackMe |
| 047 | Reversing | Ghidra | - |
| 048 | Pentesting | Pass-the-Hash | ✅ TryHackMe |
| 049 | Exploits | DEP Bypass | - |
| 050 | Pentesting | Mimikatz | ✅ TryHackMe |
| 051 | Projeto | Buffer Overflow Exploit | - |

**Meta:** Primeiro exploit funcional!

---

### Semana 8 (Dias 52-60)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 052 | Pentesting | Persistence | ✅ TryHackMe |
| 053 | Exploits | Format String | - |
| 054 | Pentesting | Credential Dumping | ✅ TryHackMe |
| 055 | Reversing | Malware Analysis | - |
| 056 | Pentesting | Pivoting | ✅ TryHackMe |
| 057 | Exploits | Heap Intro | - |
| 058 | Pentesting | Post-Exploitation | ✅ TryHackMe |
| 059 | Projeto | AD Lab Setup | - |
| 060 | Projeto | AD Compromise | ✅ Projeto |

**Meta:**
- [ ] 60 dias! Metade do trimestre
- [ ] 30+ labs TryHackMe
- [ ] AD lab comprometido
- [ ] Primeiro exploit funcional

---

## 📆 Mês 3 (Dias 61-90): Advanced

### Semana 9 (Dias 61-67)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 061 | Windows | EPROCESS Structure | - |
| 062 | Pentesting | C2 Intro | ✅ TryHackMe |
| 063 | Windows | PEB/TEB | - |
| 064 | Pentesting | Havoc C2 | ✅ TryHackMe |
| 065 | Windows | Handles | - |
| 066 | Pentesting | AV Evasion | ✅ TryHackMe |
| 067 | Windows | Tokens | - |

**Foco:** Windows Internals

---

### Semana 10 (Dias 68-74)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 068 | Pentesting | Process Injection | ✅ TryHackMe |
| 069 | Exploits | Use-After-Free | - |
| 070 | Pentesting | DLL Hijacking | ✅ TryHackMe |
| 071 | Kernel | Driver Basics | - |
| 072 | Pentesting | UAC Bypass | ✅ TryHackMe |
| 073 | Kernel | IRQL | - |
| 074 | Pentesting | Red Team Ops | ✅ TryHackMe |

---

### Semana 11 (Dias 75-81)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 075 | Kernel | DriverEntry | - |
| 076 | Pentesting | OPSEC | ✅ TryHackMe |
| 077 | Kernel | DeviceIoControl | - |
| 078 | Pentesting | Phishing | ✅ TryHackMe |
| 079 | Rootkit | DKOM Intro | - |
| 080 | Pentesting | Social Engineering | ✅ TryHackMe |
| 081 | Rootkit | Process Hiding | - |

**Foco:** Rootkit basics!

---

### Semana 12 (Dias 82-90)

| Dia | Tema | Tópico | Lab |
|-----|------|--------|-----|
| 082 | Pentesting | Full Engagement | ✅ Projeto |
| 083 | Rootkit | ActiveProcessLinks | - |
| 084 | Pentesting | Reporting | - |
| 085 | Rootkit | Driver Hiding | - |
| 086 | Projeto | Rootkit DKOM Início | - |
| 087 | Projeto | Rootkit Continuação | - |
| 088 | Projeto | Rootkit Testes | - |
| 089 | Projeto | Rootkit Finalização | - |
| 090 | Review | Revisão 90 dias | - |

**Meta final 90 dias:**
- [ ] 90 dias completados! 🎉🎉🎉
- [ ] 50+ labs TryHackMe
- [ ] 3 livros (PGTU, COD, CS:APP início)
- [ ] 3 projetos concluídos
- [ ] Rootkit DKOM funcional

---

## 📊 Resumo por Tópico

### Assembly (21 dias)
- Registradores, Stack, Funções
- Syscalls, String ops
- x64, SIMD, Inline ASM
- Debugging, ELF format

### Pentesting (45 dias)
- Web: SQLi, XSS, uploads, etc
- Network: Nmap, scanning
- AD: Kerberos, BloodHound, tickets
- Red Team: C2, evasion, OPSEC

### Arquitetura (10 dias)
- CPU pipeline, Cache
- Virtual memory, Paginação
- TLB, Performance

### Exploits (8 dias)
- Buffer overflow, ROP
- Shellcode, Format string
- Heap, UAF

### Windows/Kernel (6 dias)
- Internals: EPROCESS, PEB
- Drivers: basics, IRQL
- Rootkits: DKOM

---

## 🎯 Milestones

**Dia 30:** Primeiro mês completo 🎉
- Keylogger userland
- 13 labs THM
- PGTU completo

**Dia 60:** Segundo mês 🎉🎉
- Exploit funcional
- AD lab comprometido
- 30 labs THM

**Dia 90:** Trimestre completo! 🎉🎉🎉
- Rootkit DKOM
- 50 labs THM
- 3 livros

---

## 💡 Como Usar Este Índice

1. **Planejamento semanal:** Veja o que vem
2. **Acompanhamento:** Marque ✅ conforme completa
3. **Motivação:** Veja quanto falta para próximo milestone

**Lembre-se:** Um dia de cada vez! 🚀

---

*[[📅 Rotina-Diaria/Dia-001|→ Começar Dia 1]]*
