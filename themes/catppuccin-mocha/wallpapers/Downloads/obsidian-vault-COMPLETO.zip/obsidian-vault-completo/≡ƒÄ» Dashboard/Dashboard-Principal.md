# 🎯 Dashboard Principal

> **Última atualização:** `= date(today)`
> **Dia atual:** [Verificar qual dia você está]
> **Progresso geral:** Veja abaixo ↓

---

## 📊 Resumo Rápido

```dataview
TABLE WITHOUT ID
  ("🔥 " + dias-seguidos) as "Streak",
  ("📚 " + livros-lidos) as "Livros",
  ("🧪 " + labs-completados) as "Labs THM",
  ("💻 " + linhas-codigo) as "Código"
FROM "Daily-Notes"
WHERE file.name = date(today)
LIMIT 1
```

**Se vazio acima:** Crie sua Daily Note de hoje!

---

## 📅 Progresso da Semana

**Dias completados esta semana:**

- [ ] Segunda - Dia ___
- [ ] Terça - Dia ___
- [ ] Quarta - Dia ___
- [ ] Quinta - Dia ___
- [ ] Sexta - Dia ___
- [ ] Sábado - Dia ___
- [ ] Domingo - Dia ___

**Total:** ___/7 dias

---

## 🎯 Dias de Estudo

### Últimos 7 Dias

```dataview
TABLE WITHOUT ID
  file.name as "Data",
  tema as "Tema",
  horas as "Horas",
  concluido as "✅"
FROM "Daily-Notes"
SORT file.name DESC
LIMIT 7
```

**Horas totais (últimos 7 dias):**
```dataview
TABLE WITHOUT ID
  sum(rows.horas) as "Total de Horas"
FROM "Daily-Notes"
WHERE file.mtime >= date(today) - dur(7 days)
```

---

## 📚 Progresso de Livros

### Em Leitura Agora:

| Livro | Progresso | Páginas | Status |
|-------|-----------|---------|--------|
| Programming from the Ground Up | 0% | 0/280 | 📖 Lendo |
| Computer Organization & Design | 0% | 0/600 | ⏳ Próximo |
| CS:APP | 0% | 0/400 | ⏳ Futuro |

**Meta diária:** 10 páginas
**Dias de leitura:** Ímpares (1, 3, 5, 7, 9...)

---

## 🧪 TryHackMe Progress

**Rooms Completados:**

```dataview
TABLE WITHOUT ID
  room as "Room",
  dificuldade as "Dificuldade",
  tempo as "Tempo",
  data as "Data"
FROM "📚 Estudos/Pentesting"
WHERE tipo = "lab-completado"
SORT data DESC
LIMIT 10
```

**Estatísticas:**
- Total de rooms: ___/150
- Easy: ___
- Medium: ___
- Hard: ___

**Próximos rooms:**
- [ ] SQL Injection (Dia 2)
- [ ] Nmap (Dia 4)
- [ ] Burp Suite Basics (Dia 6)

---

## 💻 Código Escrito

**Linguagens:**

| Linguagem | Linhas | Programas |
|-----------|--------|-----------|
| Assembly | 0 | 0 |
| C | 0 | 0 |
| Python | 0 | 0 |
| Bash | 0 | 0 |

**Meta:** 50+ linhas/dia em média

---

## 🎓 Skills Adquiridas

### Assembly
- [ ] Registradores básicos (EAX, EBX, ECX, EDX)
- [ ] MOV, ADD, SUB, PUSH, POP
- [ ] Funções e Stack
- [ ] Syscalls
- [ ] x64 calling convention
- [ ] SIMD (SSE/AVX)

### Pentesting
- [ ] SQL Injection
- [ ] XSS
- [ ] Nmap scanning
- [ ] Burp Suite
- [ ] Metasploit basics
- [ ] Active Directory enum

### Arquitetura
- [ ] Pipeline de CPU
- [ ] Cache hierarchy
- [ ] Paginação
- [ ] Virtual memory
- [ ] TLB

### Exploits
- [ ] Buffer Overflow
- [ ] ROP chains
- [ ] Heap exploitation
- [ ] Format string
- [ ] Shellcode writing

---

## 🏆 Conquistas

- [ ] 🎓 **Primeiro Programa** - Hello World em Assembly
- [ ] 🔓 **First Blood** - Primeira flag no TryHackMe
- [ ] 🔥 **Streak 7** - 7 dias seguidos de estudo
- [ ] 📚 **Bookworm** - Terminou primeiro livro
- [ ] 💥 **Exploiter** - Primeiro buffer overflow
- [ ] 🎯 **Lab Master** - 10 rooms TryHackMe
- [ ] 💻 **Coder** - 1000 linhas de código
- [ ] ⚡ **Speedrunner** - 30 dias completados
- [ ] 🚀 **Rocket** - 60 dias completados
- [ ] 👑 **Legend** - 90 dias completados

---

## 📈 Gráfico de Progresso

**Dias completados por semana:**

```
Semana 1:  ███░░░░ 3/7
Semana 2:  ░░░░░░░ 0/7
Semana 3:  ░░░░░░░ 0/7
Semana 4:  ░░░░░░░ 0/7
```

**Atualização:** Manual (por enquanto)

---

## 🔥 Streak Atual

**Dias consecutivos:** 0

**Recorde:** 0

> Dica: Mínimo 30 min/dia conta como dia de estudo!

---

## 📋 Próximas Tasks (Kanban)

Ver: [[📋 Kanban/Board-Geral|Kanban Board Geral]]

**Today:**
- [ ] Abrir arquivo do dia
- [ ] Fazer leitura
- [ ] Completar lab (se dia par)
- [ ] Marcar ✅ no dia

**This Week:**
- [ ] Completar Dia 1-7
- [ ] TryHackMe: 2 rooms
- [ ] Livro: 35 páginas

**This Month:**
- [ ] 30 dias consecutivos
- [ ] Terminar PGTU
- [ ] 10 rooms TryHackMe
- [ ] Projeto: Keylogger userland

---

## 🎯 Onde Estou?

**Fase atual:** Fundamentos (Mês 1-3)

**Tópicos desta fase:**
- Assembly x86/x64
- Pentesting Web básico
- Arquitetura de computadores
- Network scanning

**Meta da fase:**
- 90 dias de estudo
- 30+ TryHackMe rooms
- 3 livros completos
- 1 projeto prático

---

## 💡 Dica da Semana

> **Esta semana:** Foque em criar o HÁBITO. Não importa se estudar 30min ou 3h, o importante é estudar TODOS os dias.

---

## 🔗 Quick Links

- [[README|Início]]
- [[📅 Rotina-Diaria/Dia-001|Começar Dia 1]]
- [[📖 Livros/Cronograma-Leitura|Cronograma de Livros]]
- [[📋 Kanban/Board-Geral|Kanban Board]]
- [[COMO-FUNCIONA|Como Funciona o Sistema]]

---

## 🎵 Motivação

**Citação do dia:**

> "The expert in anything was once a beginner."

**Lembre-se:**
- Todo dia é progresso
- Erros são aprendizado
- Consistência > Perfeição
- Você vai conseguir! 💪

---

*Atualizado automaticamente com Dataview plugin*
