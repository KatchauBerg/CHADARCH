# 🎓 Como Funciona Este Sistema

> **Versão simples e direta**

---

## 🎯 Conceito Principal

**Ideia:** Cada dia você sabe EXATAMENTE o que fazer. Sem dúvidas, sem planejamento.

**Sistema:** 
1. Acorda
2. Abre Obsidian
3. Abre `Dia-XXX.md` (o dia que você está)
4. Faz o que está escrito lá
5. Marca ✅ completado
6. Fim!

---

## 📁 Estrutura Visual

```
📂 obsidian-vault-v2/
│
├── 📅 Rotina-Diaria/         👈 SEU DIA A DIA ESTÁ AQUI!
│   ├── Dia-001.md           ← Segunda: Assembly
│   ├── Dia-002.md           ← Terça: Pentesting Lab
│   ├── Dia-003.md           ← Quarta: Assembly (stack)
│   ├── Dia-004.md           ← Quinta: Pentesting (Nmap)
│   ├── Dia-005.md           ← Sexta: Arquitetura
│   └── ... (365 dias!)
│
├── 📚 Estudos/               👈 SUAS NOTAS POR TÓPICO
│   ├── Assembly/
│   ├── Pentesting/
│   ├── Arquitetura/
│   └── ...
│
├── 📖 Livros/                👈 CRONOGRAMA DE LEITURA
│   └── Cronograma-Leitura.md  ← Qual livro ler quando
│
├── 📋 Kanban/                👈 BOARD VISUAL DE TASKS
│   └── Board-Geral.md         ← Arraste cards
│
├── 🎯 Dashboard/             👈 VER SEU PROGRESSO
│   └── Dashboard-Principal.md ← Estatísticas gerais
│
└── Templates/                👈 TEMPLATES PRONTOS
    ├── Template-Daily-Note.md
    ├── Template-Lab.md
    └── ...
```

---

## 🔄 Fluxo Diário em Detalhes

### Manhã (5-10 min)

1. **Abra Obsidian**
   
2. **Vá em `📅 Rotina-Diaria/`**
   
3. **Abra o arquivo do seu dia**
   - Dia 1? → `Dia-001.md`
   - Dia 5? → `Dia-005.md`
   - Dia 23? → `Dia-023.md`
   
4. **Leia rapidamente**
   - Veja o que vai fazer hoje
   - Quanto tempo vai levar
   - Que materiais precisa

### Durante o Dia (2-3h)

5. **Siga as instruções**
   
   Cada arquivo de dia tem:
   
   ```markdown
   📚 Leitura (1h)
   - Ler livro X, páginas Y-Z
   
   💻 Prática (1h)  
   - Exercícios práticos
   
   🧪 Lab (opcional)
   - TryHackMe room (se for dia de lab)
   ```
   
6. **Marque checkboxes** conforme completa
   ```markdown
   - [x] Li o capítulo
   - [x] Fiz exercício 1
   - [x] Fiz exercício 2
   ```

### Noite (5-10 min)

7. **Crie Daily Note** (automático)
   - Cmd/Ctrl + P → "Open today's daily note"
   
8. **Preencha estatísticas**
   ```markdown
   - Horas estudadas: 2.5h
   - Completei tudo? ✅
   - Dificuldade: ⭐⭐⭐
   ```
   
9. **Atualize Kanban** (opcional)
   - Mova "Dia-XXX" para coluna "Completado"
   - Veja próximos dias

---

## 📊 Sistema de Tracking

### Automático (com Dataview plugin)

O Dashboard calcula sozinho:
- Quantas horas você estudou
- Quantos dias seguidos
- Quantos labs completou
- Progresso de livros

**Você só precisa:**
- Preencher Daily Note com as horas
- Marcar checkboxes nos arquivos de Dia-XXX

### Manual (Kanban)

**Use o Kanban para visualizar:**
- O que falta fazer
- O que está fazendo agora
- O que já completou

**Como usar:**
1. Abra `📋 Kanban/Board-Geral.md`
2. Clique no ícone de Kanban (canto superior)
3. Arraste cards entre colunas!

---

## 🎯 Exemplo Prático Completo

### Você no Dia 1 (Segunda-feira)

**Manhã:**
1. Abre Obsidian
2. Abre `📅 Rotina-Diaria/Dia-001.md`
3. Lê que vai estudar: **Assembly - Registradores**
4. Vê que precisa de: NASM instalado

**Durante:**
5. Lê o capítulo do livro (1h)
6. Escreve 3 programas em Assembly (1h)
7. Marca tudo como ✅ completado

**Noite:**
8. Abre Daily Note de hoje
9. Anota: "2h estudadas, completei tudo ✅"
10. Vai no Kanban, move "Dia 001" para "Completado"

### Você no Dia 2 (Terça-feira)

**Manhã:**
1. Abre `📅 Rotina-Diaria/Dia-002.md`
2. Vê que é: **Pentesting - SQL Injection + Lab**
3. Tema diferente de ontem = variedade!

**Durante:**
4. Lê teoria de SQL Injection (30min)
5. Faz lab TryHackMe (1.5h)
6. Captura as flags 🎯

**Noite:**
7. Daily Note: "2h, completei lab, peguei todas flags"
8. Cria write-up usando template
9. Kanban: "Dia 002" → Completado

---

## 🔑 Recursos Principais

### 1. Arquivos de Dia (Mais Importante!)

**O que tem:**
- Teoria para ler
- Exercícios práticos
- Labs (se aplicável)
- Checkboxes para marcar

**Exemplo:**
```markdown
# Dia 003 - Assembly: Stack

## 📚 Leitura
- PGTU Cap 4, pág 67-90

## 💻 Prática
- Exercício 1: PUSH/POP
- Exercício 2: Função soma()
- Exercício 3: Stack frame

## ✅ Checklist
- [ ] Li o capítulo
- [ ] Fiz os 3 exercícios
- [ ] Entendi stack
```

### 2. Dashboard

**Veja:**
- Quantos dias você completou
- Horas totais estudadas
- Labs completados
- Skills adquiridas

**Atualização:** Automática (via Dataview)

### 3. Kanban Board

**Use para:**
- Visualizar progresso
- Organizar tasks
- Ver o que vem depois

**Como:** Arraste e solte cards

### 4. Cronograma de Livros

**Mostra:**
- Qual livro ler em cada dia
- Quantas páginas
- Em que dia do plano você está

**Integração:** Já está nos arquivos Dia-XXX!

---

## 💡 Sistema de Dias Alternados

**Padrão do vault:**

```
Dia 1 (Ímpar) → LEITURA + TEORIA
Dia 2 (Par)   → PRÁTICA + LAB
Dia 3 (Ímpar) → LEITURA + TEORIA
Dia 4 (Par)   → PRÁTICA + LAB
...
```

**Por quê?**
- Variedade = menos tédio
- Consolida conhecimento
- Balance teoria/prática

**Temas alternam:**
- Assembly → Pentesting → Arquitetura → Pentesting → Assembly...

---

## 🎨 Plugins Necessários

### Essenciais (INSTALE JÁ):

1. **Dataview** ⭐⭐⭐
   - Faz o Dashboard funcionar
   - Sem ele: dashboards vazios
   
2. **Kanban** ⭐⭐⭐
   - Board visual de tasks
   - Arrastar e soltar
   
3. **Calendar** ⭐⭐
   - Ver daily notes em calendário
   - Fácil navegação

### Úteis (opcional):

4. **Excalidraw**
   - Desenhar diagramas
   - Útil para arquitetura

5. **Templater**
   - Templates mais poderosos
   - Auto-preencher datas

**Como instalar:**
Settings → Community Plugins → Turn off Restricted Mode → Browse → Instalar

---

## 📝 Daily Notes

**O que são?**
- Registro diário do que você fez
- Automático (cria todo dia)
- Usado para estatísticas

**Formato:**
```markdown
---
horas: 2.5
concluido: true
tema: Assembly
---

# 2026-02-07

## O que fiz
- Estudei registradores
- Escrevi 3 programas
- Completei Dia 001

## Dificuldades
- Entender EBP vs ESP

## Aprendizados
- Registradores são como variáveis do CPU!
```

---

## 🚀 Começando AGORA

**3 Passos:**

1. **Instale plugins**
   - Dataview
   - Kanban
   - Calendar

2. **Abra Dia-001**
   - `📅 Rotina-Diaria/Dia-001.md`
   
3. **FAÇA!**
   - Não só leia
   - Execute as tarefas
   - Marque ✅

**E amanhã?**
- Abra Dia-002
- Repita

**Simples assim!** 🎯

---

## ❓ FAQ

### "E se eu pular um dia?"

**R:** Não tem problema!
- Volte no dia que parou
- Continue de onde parou
- Não precisa fazer 2 dias no mesmo dia

### "E se um dia for muito difícil?"

**R:** Adapte!
- Faça só metade
- Continue no próximo dia
- Volte depois para completar

### "E se eu quiser estudar mais/menos?"

**R:** Personalize!
- Arquivos são seus, modifique!
- Estude 30min ou 5h, você decide
- O sistema é flexível

### "Preciso seguir a ordem exata?"

**R:** Recomendado, mas não obrigatório
- Dias foram planejados para alternância
- Mas você pode pular para o que interessa
- Assembly é base, recomendo fazer primeiro

---

## 🎯 Lembre-se

> **O sistema funciona SE você usar.**

- Abra todo dia
- Faça as tarefas
- Marque checkboxes
- Veja progresso no Dashboard

**Consistência > Perfeição**

30 minutos TODO DIA > 5 horas num único dia

---

**Bora começar? Abra o Dia-001 AGORA!** 🚀

---

*[[README|← Voltar]] | [[📅 Rotina-Diaria/Dia-001|Começar Dia 1 →]]*
