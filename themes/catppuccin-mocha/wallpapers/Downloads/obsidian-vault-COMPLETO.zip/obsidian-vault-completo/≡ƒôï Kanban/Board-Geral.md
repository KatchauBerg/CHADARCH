---

kanban-plugin: basic

---

## 📥 Backlog

- [ ] Dia 001 - Assembly: Registradores #dia-1
- [ ] Dia 002 - Pentesting: SQL Injection #dia-2
- [ ] Dia 003 - Assembly: Stack #dia-3
- [ ] Dia 004 - Pentesting: Nmap #dia-4
- [ ] Dia 005 - Arquitetura: Pipeline #dia-5
- [ ] Dia 006 - Pentesting: Burp Suite #dia-6
- [ ] Dia 007 - Assembly: x64 #dia-7
- [ ] TryHackMe: Linux Fundamentals Part 1 #tryhackme
- [ ] TryHackMe: Linux Fundamentals Part 2 #tryhackme
- [ ] Setup Kali Linux VM #setup
- [ ] Instalar NASM + GDB #setup


## 🔄 Em Progresso

- [ ] Lendo: Programming from the Ground Up #livro


## ✅ Completado

- [x] Instalou Obsidian
- [x] Configurou vault
- [x] Instalou plugins


## 🎯 Esta Semana

- [ ] Completar Dias 1-7
- [ ] 2 rooms TryHackMe
- [ ] Ler 35 páginas do livro


## 📚 Livros

- [ ] Programming from the Ground Up - 0/280 pág
- [ ] Computer Organization - 0/600 pág  
- [ ] CS:APP - 0/400 pág (caps selecionados)


## 🧪 Labs TryHackMe

- [ ] SQL Injection (Dia 2)
- [ ] Nmap (Dia 4)
- [ ] Burp Suite Basics (Dia 6)
- [ ] XSS (Dia 8)
- [ ] Linux Fundamentals 1 (Dia 10)


## 💻 Projetos

- [ ] Keylogger Userland (Mês 1)
- [ ] Buffer Overflow Exploit (Mês 2)
- [ ] Rootkit DKOM (Mês 3)


## 🐛 Problemas / Dúvidas

- [ ] Como funciona syscall no x64?
- [ ] Diferença entre EBP e ESP?



%% Instruções de Uso do Kanban:

1. Arraste cards entre colunas
2. Clique em card para editar
3. Use tags (#dia-1, #tryhackme) para organizar
4. Archive completados periodicamente

Para usar:
- Abra este arquivo
- Habilite "Kanban" view (botão no canto)
- Arraste e solte cards!
%%
