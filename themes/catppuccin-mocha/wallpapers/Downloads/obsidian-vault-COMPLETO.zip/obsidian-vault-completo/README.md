# 🎯 Vault Completo - Rotina Diária de Estudos

> **Sistema completo com TUDO incluído!**

---

## 🚀 Início Rápido (3 Passos)

### 1️⃣ Instalar Obsidian
```bash
# Linux: sudo snap install obsidian --classic
# Windows/Mac: https://obsidian.md/download
```

### 2️⃣ Abrir Este Vault
- Obsidian → "Open folder as vault"
- Selecione esta pasta

### 3️⃣ Instalar Plugins
Settings → Community Plugins → Browse:
- ✅ **Dataview** (essencial!)
- ✅ **Kanban** (essencial!)
- ✅ **Calendar** (recomendado)

**Enable todos depois de instalar!**

---

## 📁 O Que Tem Neste Vault?

### ✅ Rotina Dia a Dia Completa
`📅 Rotina-Diaria/` - 90 dias planejados
- Cada dia com instruções específicas
- Livros, páginas, exercícios, labs
- Checkboxes para marcar progresso

### ✅ Pastas de Estudo Organizadas
`📚 Estudos/` - Suas notas por matéria
- **Assembly/** - Registradores, Stack, Funções, etc
- **Pentesting/Web/** - SQLi, XSS, uploads, etc
- **Pentesting/Network/** - Nmap, scanning, enum
- **Pentesting/AD/** - Kerberos, BloodHound, tickets
- **Arquitetura/** - CPU, cache, memória
- **Exploits/** - Buffer overflow, ROP, shellcode
- **Windows-Internals/** - EPROCESS, PEB, handles
- **Reversing/** - IDA, Ghidra, malware
- **Kernel-Rootkit/** - Drivers, DKOM, hooks

### ✅ Labs TryHackMe
`🧪 Labs-TryHackMe/` - Write-ups organizados
- Templates prontos
- Exemplos inclusos

### ✅ Projetos Práticos
`💻 Projetos/` - Código e documentação
- Keylogger userland (Mês 1)
- Buffer overflow exploit (Mês 2)
- Rootkit DKOM (Mês 3)

### ✅ Sistema de Tracking
- `🎯 Dashboard/` - Progresso automático
- `📋 Kanban/` - Board visual
- `Daily-Notes/` - Registro diário

### ✅ Cronograma de Livros
`📖 Livros/` - Sabe o que ler quando
- Resumos por capítulo
- Cronograma diário

---

## 🎯 Como Usar

### Todo Dia:
1. **Manhã:** Abra `📅 Rotina-Diaria/Dia-XXX.md`
2. **Durante:** Siga instruções, estude, pratique
3. **Noite:** Crie Daily Note, anote progresso

### Fazer Anotações:
- Estudando Assembly? → `📚 Estudos/Assembly/`
- Fazendo lab? → `🧪 Labs-TryHackMe/WriteUps/`
- Código? → `💻 Projetos/Codigo/`

### Ver Progresso:
- `🎯 Dashboard/Dashboard-Principal.md`
- `📋 Kanban/Board-Geral.md`

---

## 📚 Estrutura Visual

```
📦 obsidian-vault-completo/
│
├── 📅 Rotina-Diaria/          👈 SEU DIA A DIA
│   ├── Dia-001.md ... Dia-090.md
│   └── INDICE-90-DIAS.md
│
├── 📚 Estudos/                👈 SUAS NOTAS
│   ├── Assembly/
│   │   ├── 01-Registradores.md
│   │   ├── 02-Stack.md
│   │   └── 03-Funcoes.md
│   ├── Pentesting/
│   │   ├── Web/
│   │   │   ├── SQL-Injection.md
│   │   │   └── XSS.md
│   │   ├── Network/
│   │   └── AD/
│   ├── Arquitetura/
│   ├── Exploits/
│   └── ...
│
├── 🧪 Labs-TryHackMe/         👈 WRITE-UPS
│   └── WriteUps/
│       ├── SQL-Injection.md
│       └── Nmap.md
│
├── 💻 Projetos/               👈 CÓDIGO
│   └── Codigo/
│       ├── keylogger/
│       └── exploits/
│
├── 📖 Livros/                 👈 CRONOGRAMA
│   ├── Cronograma-Leitura.md
│   └── Resumos/
│
├── 🎯 Dashboard/              👈 PROGRESSO
│   └── Dashboard-Principal.md
│
├── 📋 Kanban/                 👈 TASKS
│   └── Board-Geral.md
│
└── Templates/                 👈 TEMPLATES
    ├── Template-Daily-Note.md
    ├── Template-Lab.md
    └── Template-Estudo.md
```

---

## 🎓 Começar AGORA

**Opção 1: Leitura Completa**
1. Leia este README
2. Leia `COMO-FUNCIONA.md`
3. Abra `Dia-001.md`

**Opção 2: Direto ao Ponto**
→ Abra `📅 Rotina-Diaria/Dia-001.md` e comece!

---

## ✅ O Que Torna Este Vault Completo?

- ✅ 90 dias detalhados
- ✅ Pastas de estudo COM exemplos
- ✅ Templates prontos
- ✅ Dashboard funcional
- ✅ Kanban configurado
- ✅ Cronograma de livros
- ✅ Write-ups de exemplo
- ✅ Estrutura completa

**Nada falta! Tudo pronto para usar!** 🚀

---

**Bora começar? Vá para:** `📅 Rotina-Diaria/Dia-001.md`
