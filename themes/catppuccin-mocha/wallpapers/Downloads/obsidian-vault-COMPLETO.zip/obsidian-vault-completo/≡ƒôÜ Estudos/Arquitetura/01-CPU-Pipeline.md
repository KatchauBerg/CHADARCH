# CPU Pipeline

> **Estudado em:** [[📅 Rotina-Diaria/Dia-005|Dia 005]]

## O Que É?

Pipeline = linha de montagem do CPU

**Estágios:**
1. Fetch (buscar instrução)
2. Decode (decodificar)
3. Execute (executar)
4. Memory (acessar memória)
5. Write Back (escrever resultado)

## Vantagens

- Mais instruções por segundo
- Melhor throughput

## Hazards

1. **Data Hazard** - instrução depende de outra
2. **Control Hazard** - branch/jump
3. **Structural Hazard** - recurso ocupado

**Tags:** #arquitetura #pipeline #cpu
