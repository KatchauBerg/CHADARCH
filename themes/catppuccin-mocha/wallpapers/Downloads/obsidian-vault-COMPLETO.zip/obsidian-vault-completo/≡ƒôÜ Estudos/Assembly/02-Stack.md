# Stack (Pilha) em Assembly

> **Estudado em:** [[📅 Rotina-Diaria/Dia-003|Dia 003]]  
> **Livro:** PGTU Cap 4

---

## 📝 O Que É o Stack?

**Definição:** Uma área de memória que funciona como uma pilha de pratos - Last In, First Out (LIFO).

**Analogia:** Pilha de pratos - você só pode tirar o de cima!

---

## 🔧 Instruções Básicas

### PUSH - Colocar na pilha
```asm
push eax        ; Coloca valor de EAX no topo do stack
```

**O que acontece:**
1. ESP diminui 4 bytes (32-bit)
2. Valor é copiado para [ESP]

### POP - Tirar da pilha
```asm
pop ebx         ; Tira valor do topo e coloca em EBX
```

**O que acontece:**
1. Valor em [ESP] é copiado para EBX
2. ESP aumenta 4 bytes

---

## 💻 Exemplo Prático

```asm
mov eax, 10     ; EAX = 10
push eax        ; Stack: [10]

mov eax, 20     ; EAX = 20  
push eax        ; Stack: [20, 10]

pop ebx         ; EBX = 20, Stack: [10]
pop ecx         ; ECX = 10, Stack: []
```

---

## 🎯 ESP e EBP

### ESP (Stack Pointer)
- Aponta para o **topo** do stack
- Muda automaticamente com PUSH/POP

### EBP (Base Pointer)  
- Aponta para a **base** do stack frame
- Usado em funções

---

## 🔗 Links

- [[01-Registradores|Registradores (ESP/EBP)]]
- [[03-Funcoes|Funções e Stack Frames]]

---

**Tags:** #assembly #stack #esp #ebp #dia-003
