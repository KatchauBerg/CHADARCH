# Registradores em Assembly x86

> **Estudado em:** [[📅 Rotina-Diaria/Dia-001|Dia 001]]  
> **Livro:** Programming from the Ground Up - Cap 2

---

## 📝 O Que São Registradores?

**Definição:** Pequenos espaços de armazenamento DENTRO do CPU, super rápidos!

**Analogia:** São como as "mãos" do CPU - onde ele segura dados enquanto trabalha.

---

## 🔧 Registradores Principais (32-bit)

### Registradores de Propósito Geral

| Registrador | Nome | Uso Principal |
|-------------|------|---------------|
| **EAX** | Accumulator | Aritmética, retorno de funções |
| **EBX** | Base | Ponteiro para dados |
| **ECX** | Counter | Loops, contadores |
| **EDX** | Data | I/O, multiplicação/divisão |

### Registradores de Ponteiro

| Registrador | Nome | Uso |
|-------------|------|-----|
| **ESP** | Stack Pointer | Topo da pilha |
| **EBP** | Base Pointer | Base do stack frame |
| **ESI** | Source Index | String operations (origem) |
| **EDI** | Destination Index | String operations (destino) |

### Registrador Especial

| Registrador | Nome | Uso |
|-------------|------|-----|
| **EIP** | Instruction Pointer | Próxima instrução a executar |

---

## 💻 Exemplos Práticos

### Mover Valores

```asm
mov eax, 5          ; EAX = 5
mov ebx, 10         ; EBX = 10
mov ecx, eax        ; ECX = EAX (ECX = 5)
```

### Aritmética

```asm
mov eax, 10         ; EAX = 10
add eax, 5          ; EAX = EAX + 5 (EAX = 15)
sub eax, 3          ; EAX = EAX - 3 (EAX = 12)
```

### Usando Diferentes Registradores

```asm
; Soma usando diferentes registradores
mov eax, 10         ; Accumulator: número 1
mov ebx, 20         ; Base: número 2
add eax, ebx        ; Soma em EAX
; Resultado: EAX = 30
```

---

## 🎯 Sub-registradores (8-bit e 16-bit)

### EAX Subdivisions

```
EAX (32 bits): [    EAX     ]
AX  (16 bits):      [ AX    ]
AH  (8 bits):       [AH]
AL  (8 bits):          [AL]
```

**Exemplo:**
```asm
mov eax, 0x12345678
; EAX = 0x12345678
; AX  = 0x5678
; AH  = 0x56
; AL  = 0x78
```

---

## 🧠 Regras Importantes

1. **EAX** - Sempre usado para retorno de funções
2. **ECX** - Tradicionalmente para loops
3. **ESP** - NUNCA modifique diretamente (a menos que saiba o que está fazendo!)
4. **EIP** - Não pode ser movido diretamente (use JMP, CALL, RET)

---

## ⚠️ Erros Comuns

### ❌ Erro 1: Esquecer de inicializar
```asm
add eax, 5      ; EAX contém lixo!
```

### ✅ Correto:
```asm
mov eax, 0      ; Inicializa
add eax, 5      ; Agora EAX = 5
```

### ❌ Erro 2: Confundir tamanhos
```asm
mov eax, 256
mov al, eax     ; Trunca! AL só pega últimos 8 bits
```

---

## 🔗 Links Relacionados

- [[02-Stack|Stack e ESP/EBP]]
- [[03-Funcoes|Uso de registradores em funções]]
- [[📅 Rotina-Diaria/Dia-001|Dia 001 - Prática]]

---

## ✅ Checklist de Entendimento

- [ ] Sei o que é um registrador
- [ ] Conheço os 8 principais registradores
- [ ] Entendo MOV e ADD
- [ ] Consigo usar EAX, EBX, ECX, EDX
- [ ] Sei a diferença entre EAX, AX, AH, AL

---

**Tags:** #assembly #registradores #fundamentos #dia-001
