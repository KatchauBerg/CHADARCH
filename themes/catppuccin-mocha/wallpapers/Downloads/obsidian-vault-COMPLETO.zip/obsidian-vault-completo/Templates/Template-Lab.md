# [Nome do Lab/Room]

> **Plataforma:** TryHackMe  
> **Dificuldade:** Easy/Medium/Hard  
> **Data:** {{date:YYYY-MM-DD}}

---

## 📋 Informações

- **IP:** `10.10.X.X`
- **Flags:** _X/Y_

---

## 🔍 Enumeration

### Nmap
```bash
nmap -sV -sC 10.10.X.X
```

**Portas abertas:**
- 

---

## 🚪 Initial Access

**Vetor:**

**Exploit:**
```bash

```

---

## 🔑 Flags

**User:** `THM{...}`  
**Root:** `THM{...}`

---

## 📝 Write-up Completo

[Seu write-up aqui]

---

**Tags:** #tryhackme #lab #writeup
