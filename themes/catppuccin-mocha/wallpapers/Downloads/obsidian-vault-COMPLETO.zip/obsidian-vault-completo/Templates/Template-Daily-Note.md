---
horas: 
concluido: false
tema: 
dia-rotina: 
---

# {{date:YYYY-MM-DD}} - Daily Note

## 📅 Dia da Rotina

**Dia:** ___ (ex: Dia-001, Dia-015, etc)

**Link:** [[📅 Rotina-Diaria/Dia-___]]

---

## ✅ O Que Fiz Hoje

- [ ] Leitura / Teoria
- [ ] Exercícios práticos
- [ ] Lab TryHackMe (se aplicável)
- [ ] Anotações/Resumo

**Detalhes:**


---

## 📚 Leitura

**Livro:** 
**Páginas:** ___ até ___

**Resumo rápido:**


---

## 💻 Prática

**Código escrito:**
- Assembly: ___ linhas
- C/Python/Bash: ___ linhas

**Programas/Scripts:**
1. 
2. 

---

## 🧪 Labs TryHackMe

**Room:** 

**Flags capturadas:**
- User: 
- Root: 

**Dificuldade:** ⭐⭐⭐ (1-5)

**Write-up:** [[link]]

---

## 📊 Estatísticas

- **Horas totais:** ___h
  - Leitura: ___h
  - Prática: ___h
  - Labs: ___h

- **Completei o dia?** ✅ / 🤔 Parcial / ❌

- **Energia/Motivação:** ⭐⭐⭐⭐⭐ (1-5)

---

## 🧠 Aprendizados do Dia

**3 principais coisas que aprendi:**
1. 
2. 
3. 

---

## 🐛 Dificuldades / Dúvidas

**Travei em:**


**Ainda não entendi:**


**Preciso revisar:**


---

## 💡 Insights / Ideias

**Conexões que fiz:**


**Ideias para projetos:**


---

## 🎯 Plano para Amanhã

**Próximo dia:** [[📅 Rotina-Diaria/Dia-___]]

**Preview:**
- 
- 

---

## 🏆 Conquistas

- [ ] Completei o dia
- [ ] Streak continua (__ dias)
- [ ] Nova conquista desbloqueada: ___

---

**Tags:** #daily-note #dia-___ #{{date:YYYY-MM}}

---

*[[🎯 Dashboard/Dashboard-Principal|← Dashboard]]*
